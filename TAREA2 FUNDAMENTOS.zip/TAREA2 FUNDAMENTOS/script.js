function validarLogin() {
    var usuario = document.getElementById('usuario').value;
    var clave = document.getElementById('clave').value;

    if (usuario === 'cenfo' && clave === '123') {
        Swal.fire({
            title: '¡Inicio de sesión exitoso!',
            text: 'Redirigiendo...',
            icon: 'success',
            showConfirmButton: false,
            timer: 2000 // 2 segundos
        }).then(() => {
            window.location.href = 'inicio.html'; // Redirige a la página de proyectos
        });
        return false;
    } else {
        Swal.fire({
            title: 'Error',
            text: 'Usuario o clave incorrectos',
            icon: 'error'
        });
        return false;
    }
}

