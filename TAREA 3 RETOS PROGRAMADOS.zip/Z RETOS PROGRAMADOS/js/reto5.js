const versiones = {
    'model-s': [
        {version: 'Long Range', precio: 79999, imagen: 'images/model-s-long-range.jpg'},
        {version: 'Plaid', precio: 119999, imagen: 'images/model-s-plaid.jpg'}
    ],
    'model-3': [
        {version: 'Standard Range Plus', precio: 39999, imagen: 'images/model-3-standard.jpg'},
        {version: 'Performance', precio: 55999, imagen: 'images/model-3-performance.jpg'}
    ],
    'model-x': [
        {version: 'Long Range', precio: 89999, imagen: 'images/model-x-long-range.jpg'},
        {version: 'Plaid', precio: 119999, imagen: 'images/model-x-plaid.jpg'}
    ],
    'model-y': [
        {version: 'Long Range', precio: 49999, imagen: 'images/model-y-long-range.jpg'},
        {version: 'Performance', precio: 59999, imagen: 'images/model-y-performance.jpg'}
    ]
};

function actualizarVersiones() {
    const modeloCombo = document.getElementById('modeloCombo');
    const versionCombo = document.getElementById('versionCombo');
    const modeloSeleccionado = modeloCombo.value;

    // Limpiar opciones previas
    versionCombo.innerHTML = '<option value="" disabled selected>Selecciona una versión</option>';
    
    if (versiones[modeloSeleccionado]) {
        versiones[modeloSeleccionado].forEach(v => {
            const option = document.createElement('option');
            option.value = v.version;
            option.textContent = v.version;
            versionCombo.appendChild(option);
        });
    }
}

function calcularPrecio() {
    const modeloCombo = document.getElementById('modeloCombo');
    const versionCombo = document.getElementById('versionCombo');
    const descripcion = document.getElementById('descripcion');
    const imagen = document.getElementById('imagen');
    const precioSpan = document.getElementById('precio');

    const modeloSeleccionado = modeloCombo.value;
    const versionSeleccionada = versionCombo.value;

    if (!modeloSeleccionado || !versionSeleccionada) {
        Swal.fire({
            title: 'Error',
            text: 'Por favor, seleccione un modelo y una versión.',
            icon: 'error'
        });
        return;
    }

    const versionInfo = versiones[modeloSeleccionado].find(v => v.version === versionSeleccionada);

    if (versionInfo) {
        descripcion.innerText = `Modelo: ${modeloSeleccionado}, Versión: ${versionSeleccionada}`;
        imagen.src = versionInfo.imagen;
        precioSpan.innerText = `$${versionInfo.precio.toLocaleString()}`;
    }
}
