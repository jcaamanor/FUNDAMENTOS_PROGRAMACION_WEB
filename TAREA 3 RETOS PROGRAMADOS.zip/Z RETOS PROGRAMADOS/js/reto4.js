function mostrarPais() {
    const paisCombo = document.getElementById("countryCombo");
    const paisSeleccionado = paisCombo.value;
    const countryInfo = document.getElementById("countryInfo");
    
    const descripcion = document.createElement('div');
    const imagen = document.createElement('img');

    switch (paisSeleccionado) {
        case "costa-rica":
            descripcion.innerText = "Costa Rica: Es un pais centroamerico conocida por sus impresionantes playas, volcanes y biodiversidad.";
            imagen.src = "images/costa-rica.jpg";
            break;
        case "usa":
            descripcion.innerText = "USA: País norteamericano destacado por su influencia cultural, económica y política en el mundo.";
            imagen.src = "images/usa.jpg";
            break;
        case "japon":
            descripcion.innerText = "Japón: País asiatico famoso por su tecnología avanzada, cultura tradicional y belleza natural.";
            imagen.src = "images/japon.jpg";
            break;
        case "italia":
            descripcion.innerText = "Italia: Pais Europeo conocido por su arte, historia, cocina y paisajes variados.";
            imagen.src = "images/italia.jpg";
            break;
        case "francia":
            descripcion.innerText = "Francia: País Europeo muy famoso por su historia, cultura, gastronomía y moda.";
            imagen.src = "images/francia.jpg";
            break;
        default:
            descripcion.innerText = "";
            imagen.src = "";
            break;
    }

    // Limpiar contenido anterior
    countryInfo.innerHTML = "";
    
    // Añadir la imagen y el texto al contenedor
    countryInfo.appendChild(imagen);
    countryInfo.appendChild(descripcion);
}
