function showInfo(part) {
    let description = '';
    switch(part) {
        case 'Turbo Cargador':
            description = 'El turbo cargador aumenta la potencia del motor.';
            break;
        case 'Intercooler':
            description = 'El intercooler reduce la temperatura del aire comprimido.';
            break;
        case 'Oxido Nitroso':
            description = 'El óxido nitroso proporciona una mayor aceleración temporal.';
            break;
        case 'Motor de un Skyline':
            description = 'El motor del Nissan Skyline es famoso por su rendimiento.';
            break;
        case 'Mufla de Competencia':
            description = 'La mufla de competencia reduce la contrapresión y mejora el sonido.';
            break;
        default:
            description = 'Descripción no disponible.';
    }

    let timerInterval;
    Swal.fire({
        title: part,
        html: `${description} <br><br><b>Tiempo restante: <strong></strong> segundos</b>`,
        timer: 5000,
        timerProgressBar: true,
        didOpen: () => {
            Swal.showLoading();
            timerInterval = setInterval(() => {
                const content = Swal.getHtmlContainer();
                if (content) {
                    const b = content.querySelector('strong');
                    if (b) {
                        b.textContent = Math.ceil(Swal.getTimerLeft() / 1000);
                    }
                }
            }, 100);
        },
        willClose: () => {
            clearInterval(timerInterval);
        }
    });
}
