function generarFactura() {
    const cliente = document.getElementById("cliente").value.trim();
    const articulo = document.getElementById("articulo").value.trim();
    const cantidad = parseInt(document.getElementById("cantidad").value);
    const precio = parseFloat(document.getElementById("precio").value);

    // Validar que todos los campos estén llenos
    if (!cliente || !articulo || isNaN(cantidad) || isNaN(precio)) {
        Swal.fire({
            title: 'Error',
            text: 'Todos los campos deben estar llenos.',
            icon: 'error'
        });
        return;
    }

    // Validar que cantidad y precio sean mayores que 0
    if (cantidad <= 0 || precio <= 0) {
        Swal.fire({
            title: 'Error',
            text: 'La cantidad y el precio deben ser mayores que 0.',
            icon: 'error'
        });
        return;
    }

    const subtotal = cantidad * precio;
    const iva = subtotal * 0.13;
    const servicio = subtotal * 0.05;
    const total = subtotal + iva + servicio;
    const facturaNo = Math.floor(Math.random() * 1000) + 1;
    const fecha = new Date().toLocaleString();

    // Actualizar los elementos con los valores calculados
    document.getElementById("detalleFacturaNo").innerText = `Factura No. ${facturaNo}`;
    document.getElementById("detalleFecha").innerText = `Fecha: ${fecha}`;
    document.getElementById("detalleCliente").innerText = `Cliente: ${cliente}`;
    document.getElementById("detalleArticulo").innerText = articulo;
    document.getElementById("detalleCantidad").innerText = cantidad;
    document.getElementById("detallePrecio").innerText = `₡${precio.toFixed(2)}`;
    document.getElementById("subtotal").innerText = `₡${subtotal.toFixed(2)}`;
    document.getElementById("iva").innerText = `₡${iva.toFixed(2)}`;
    document.getElementById("servicio").innerText = `₡${servicio.toFixed(2)}`;
    document.getElementById("total").innerText = `₡${total.toFixed(2)}`;
}

function borrarFactura() {
    document.getElementById("cliente").value = '';
    document.getElementById("articulo").value = '';
    document.getElementById("cantidad").value = '';
    document.getElementById("precio").value = '';

    document.getElementById("detalleFacturaNo").innerText = '';
    document.getElementById("detalleFecha").innerText = '';
    document.getElementById("detalleCliente").innerText = '';
    document.getElementById("detalleArticulo").innerText = '';
    document.getElementById("detalleCantidad").innerText = '';
    document.getElementById("detallePrecio").innerText = '';
    document.getElementById("subtotal").innerText = '';
    document.getElementById("iva").innerText = '';
    document.getElementById("servicio").innerText = '';
    document.getElementById("total").innerText = '';
}
