function convertirDolares() {
    const montoDolares = parseFloat(document.getElementById('montoDolares').value);
    const tipoCambioDolares = parseFloat(document.getElementById('tipoCambioDolares').value);

    if (isNaN(montoDolares) || isNaN(tipoCambioDolares) || montoDolares <= 0 || tipoCambioDolares <= 0) {
        Swal.fire({
            title: 'Error',
            text: 'Por favor, ingrese valores válidos para ambos campos.',
            icon: 'error'
        });
        return;
    }

    const resultadoColones = montoDolares * tipoCambioDolares;
    document.getElementById('resultadoColones').textContent = `₡${resultadoColones.toFixed(2)}`;
}

function convertirColones() {
    const montoColones = parseFloat(document.getElementById('montoColones').value);
    const tipoCambioColones = parseFloat(document.getElementById('tipoCambioColones').value);

    if (isNaN(montoColones) || isNaN(tipoCambioColones) || montoColones <= 0 || tipoCambioColones <= 0) {
        Swal.fire({
            title: 'Error',
            text: 'Por favor, ingrese valores válidos para ambos campos.',
            icon: 'error'
        });
        return;
    }

    const resultadoDolares = montoColones / tipoCambioColones;
    document.getElementById('resultadoDolares').textContent = `$${resultadoDolares.toFixed(2)}`;
}

function limpiarFormulario(formId, resultadoId) {
    document.getElementById(formId).reset();
    document.getElementById(resultadoId).textContent = '';
}
