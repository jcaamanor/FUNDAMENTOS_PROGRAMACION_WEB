document.addEventListener('DOMContentLoaded', function() {
    const buscadorForm = document.getElementById('buscadorForm');
    const cedulaInput = document.getElementById('cedula');
    const resultadoContainer = document.getElementById('resultado');


    buscadorForm.addEventListener('submit', function(event) {
        event.preventDefault();
    
        const cedula = cedulaInput.value.trim();

        // Aca se verifica si el campo de cédula está vacío
        if (cedula.length === 0) {
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: 'Por favor ingresa una cédula antes de buscar.'
            });
        } else if (isNaN(cedula)) {
     
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: 'La cédula ingresada no es válida.'
            });
        } else if (validarCedula(cedula)) {
 
            mostrarInformacionEmpleado(cedula);
        } else {
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: 'La cédula ingresada no es válida.'
            });
        }
    });

    // valida cédula
    function validarCedula(cedula) {
     
        return /^\d{9}$/.test(cedula);
    }


    function mostrarInformacionEmpleado(cedula) {
        // Objeto con las caracteristicas delos empleados
        const empleados = {
            '109110338': { nombre: 'Juan', apellidos: 'Rojas', lugar: 'San José', regimen: 'Diurno', ingreso: 2010, departamento: 'Ingenieria', imagen: 'images/juan.png' },
            '209110338': { nombre: 'Aaron', apellidos: 'Fonseca', lugar: 'Heredia', regimen: 'Nocturno', ingreso: 2012, departamento: 'Soporte Técnico', imagen: 'images/carlos.png' },
            '309110338': { nombre: 'Natalia', apellidos: 'Fonseca', lugar: 'Alajuela', regimen: 'Diurno', ingreso: 2014, departamento: 'Análisis de Datos', imagen: 'images/natalia.png' },
            '409110338': { nombre: 'Monica', apellidos: 'Fonseca', lugar: 'Cartago', regimen: 'Mixto', ingreso: 2016, departamento: 'Diseño Gráfico', imagen: 'images/monica.png' },
            '509110338': { nombre: 'Tafnis', apellidos: 'Fonseca', lugar: 'Guanacaste', regimen: 'Nocturno', ingreso: 2018, departamento: 'Finanzas', imagen: 'images/tafnis.png' }
        };

   
        if (empleados[cedula]) {
            const empleado = empleados[cedula];

            mostrarResultado(empleado);
        } else {
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: 'El usuario que ha digitado no existe en este registro.'
            });
        }
    }


    function mostrarResultado(empleado) {
   
        resultadoContainer.innerHTML = `
               <div class="card" style="width: 18rem; margin: auto;">
            <img src="${empleado.imagen}" class="card-img-top" alt="${empleado.nombre}">
            <div class="card-body">
                <h3 class="card-title">Informacion del Empleado</h3>
                 </div>
                <p class="card-text"><strong>Nombre:</strong>${empleado.nombre} </p>
                <p class="card-text"><strong>Apellido:</strong>${empleado.apellidos}</p>
                <p class="card-text"><strong>Lugar:</strong> ${empleado.lugar}</p>
                <p class="card-text"><strong>Régimen:</strong> ${empleado.regimen}</p>
                <p class="card-text"><strong>Año de Ingreso:</strong> ${empleado.ingreso}</p>
                <p class="card-text"><strong>Departamento:</strong> ${empleado.departamento}</p>
            </div>
        </div>
    `;
}
    // Función para hacer una nueva busqueda , limpia los campos
    window.borrar = function() {
        cedulaInput.value = '';
        resultadoContainer.innerHTML = '';
    };
});