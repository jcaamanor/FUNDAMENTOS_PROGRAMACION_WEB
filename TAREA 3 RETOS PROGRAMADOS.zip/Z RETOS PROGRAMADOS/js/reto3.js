function irAlEnlace() {
    const linkCombo = document.getElementById("linkCombo");
    const selectedLink = linkCombo.value;

    if (!selectedLink) {
        Swal.fire({
            title: 'Error',
            text: 'Por favor, seleccione un enlace.',
            icon: 'error'
        });
        return;
    }

    window.open(selectedLink, '_blank');
}
