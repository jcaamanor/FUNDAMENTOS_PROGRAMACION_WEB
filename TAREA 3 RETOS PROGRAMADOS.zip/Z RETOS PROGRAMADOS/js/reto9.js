const carImages = {
    rojo: 'images/frojo.jpg',
    azul: 'images/fazul.jpg',
    blanco: 'images/fblanco.jpg',
    negro: 'images/fnegro.jpg',
    gris: 'images/fgris.jpg'
};

const basePrice = 200000;  // Precio base del Ferrari
const extraPrice = 5000;   // Precio de cada extra

// Function to show the selected car image based on checkbox
function mostrarImagen() {
    const selectedColor = document.querySelector('input[name="color"]:checked').value;
    const carImage = document.getElementById('ferrari-image');
    carImage.src = carImages[selectedColor];
    carImage.style.display = 'block';
}

function cotizarAuto() {
    const selectedExtras = document.querySelectorAll('input[name="extra"]:checked');
    const selectedColor = document.querySelector('input[name="color"]:checked');

    if (!selectedColor) {
        Swal.fire({
            title: 'Error',
            text: 'Seleccione un color para el auto.',
            icon: 'error'
        });
        return;
    }

    if (selectedExtras.length === 0) {
        Swal.fire({
            title: 'Error',
            text: 'Seleccione al menos una personalización.',
            icon: 'error'
        });
        return;
    }

    const extras = Array.from(selectedExtras).map(extra => extra.value);
    const extrasCost = extras.length * extraPrice;
    const iva = (basePrice + extrasCost) * 0.13;
    const total = basePrice + extrasCost + iva;

    let resultadoHtml = `<p>Precio base: $${basePrice.toLocaleString()}</p>`;
    resultadoHtml += '<p>Extras seleccionadas:</p><ul>';
    extras.forEach(extra => {
        resultadoHtml += `<li>${extra}: $${extraPrice.toLocaleString()}</li>`;
    });
    resultadoHtml += '</ul>';
    resultadoHtml += `<p>IVA (13%): $${iva.toFixed(2)}</p>`;
    resultadoHtml += `<p><strong>Total a pagar: $${total.toLocaleString()}</strong></p>`;

    document.getElementById('resultado').innerHTML = resultadoHtml;
    document.getElementById('resultado-section').style.display = 'block';
}

// Attach event listeners to color radio buttons
document.querySelectorAll('input[name="color"]').forEach(radio => {
    radio.addEventListener('change', mostrarImagen);
});

// Set a default image on page load
window.onload = function() {
    document.querySelector('input[name="color"][value="rojo"]').checked = true;
    mostrarImagen();
}
