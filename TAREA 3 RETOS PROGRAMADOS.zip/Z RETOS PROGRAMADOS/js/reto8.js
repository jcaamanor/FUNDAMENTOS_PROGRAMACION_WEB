let estudiantes = [];

function agregarEstudiante() {
    const nombre = document.getElementById('nombre').value.trim();
    const apellidos = document.getElementById('apellidos').value.trim();
    const nota1 = parseFloat(document.getElementById('nota1').value);
    const nota2 = parseFloat(document.getElementById('nota2').value);
    const nota3 = parseFloat(document.getElementById('nota3').value);

    if (!nombre || !apellidos || isNaN(nota1) || isNaN(nota2) || isNaN(nota3)) {
        Swal.fire({
            title: 'Error',
            text: 'Todos los campos deben estar llenos.',
            icon: 'error'
        });
        return;
    }

    if (!/^[a-zA-Z\s]+$/.test(nombre) || !/^[a-zA-Z\s]+$/.test(apellidos)) {
        Swal.fire({
            title: 'Error',
            text: 'El nombre y apellidos deben contener solo letras.',
            icon: 'error'
        });
        return;
    }

    if (nota1 < 0 || nota1 > 100 || nota2 < 0 || nota2 > 100 || nota3 < 0 || nota3 > 100) {
        Swal.fire({
            title: 'Error',
            text: 'Las notas deben ser valores numéricos entre 0 y 100.',
            icon: 'error'
        });
        return;
    }

    const estudiante = { nombre, apellidos, notas: [nota1, nota2, nota3] };
    estudiantes.push(estudiante);

    const option = document.createElement('option');
    option.value = estudiantes.length - 1;
    option.text = `${nombre} ${apellidos}`;
    document.getElementById('estudiantes').appendChild(option);

    document.getElementById('registroForm').reset();

    Swal.fire({
        title: 'Éxito',
        text: 'Estudiante agregado correctamente.',
        icon: 'success'
    });
}

function calcularPromedio() {
    const select = document.getElementById('estudiantes');
    const selectedIndex = select.selectedIndex;
    if (selectedIndex < 0) {
        Swal.fire({
            title: 'Error',
            text: 'Seleccione un estudiante.',
            icon: 'error'
        });
        return;
    }

    const estudiante = estudiantes[selectedIndex];
    const promedio = (estudiante.notas.reduce((a, b) => a + b, 0)) / estudiante.notas.length;

    Swal.fire({
        title: 'Promedio',
        text: `El promedio de ${estudiante.nombre} ${estudiante.apellidos} es ${promedio.toFixed(2)}.`,
        icon: 'info'
    });
}
