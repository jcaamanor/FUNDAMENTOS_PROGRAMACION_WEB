let currentIndex = 0;

document.getElementById('nextButton').addEventListener('click', () => {
    const items = document.querySelectorAll('.carousel-item');
    if (currentIndex < items.length - 1) {
        currentIndex++;
    } else {
        currentIndex = 0;
    }
    updateCarousel(items);
});

document.getElementById('prevButton').addEventListener('click', () => {
    const items = document.querySelectorAll('.carousel-item');
    if (currentIndex > 0) {
        currentIndex--;
    } else {
        currentIndex = items.length - 1;
    }
    updateCarousel(items);
});

function updateCarousel(items) {
    items.forEach((item, index) => {
        item.style.transform = `translateX(-${currentIndex * 100}%)`;
    });
    const selectedColor = items[currentIndex].getAttribute('data-color');
    document.getElementById('selectedColor').innerText = `Color seleccionado: ${selectedColor}`;
    console.log(`Current Index: ${currentIndex}, Selected Color: ${selectedColor}`);
}
